Before run the script please run **npm install** to install all necessary dependencies

* Get the current total supply
node script.js getTotalSupply
* Mint new tokens
node script.js mint --toAddress=0xAb5801a7D398351b8bE11C439e05C5B3259aeC9B --mintAmount=1000
